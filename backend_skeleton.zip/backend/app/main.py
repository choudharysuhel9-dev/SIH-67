"""
app/main.py

Entry point of the FastAPI backend.

STATUS: Skeleton only (Task 1 - folder structure).
The actual FastAPI app instance, CORS config, routers,
and /api/health endpoint will be added in a later task
(Phase 1, Section 4 of the plan) so we don't jump ahead.

Run this file with:
    uvicorn app.main:app --reload
"""

# TODO (next task): create FastAPI() app instance here
# TODO (next task): add CORS middleware
# TODO (next task): include routers from app/api/
# TODO (next task): add GET /api/health endpoint

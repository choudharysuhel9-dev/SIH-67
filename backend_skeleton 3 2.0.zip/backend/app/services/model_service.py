"""
app/services/model_service.py

Backs GET /api/model.

STATUS: Mock data only (deterministic, not random, so responses are
stable and testable). validate_variable/validate_depth/validate_time
are reused by current_service.py and comparison_service.py so every
endpoint rejects bad input the same way.

WHEN REAL NETCDF IS CONNECTED (later task):
- LAT_RANGE / LON_RANGE come from ds.latitude.values / ds.longitude.values
- validate_depth/validate_time should check against ds.depth.values /
  ds.time.values instead of the DEPTHS constant
- _mock_value() is replaced by ds[variable].sel(depth=depth, time=time,
  method="nearest").values
- get_model_data() keeps the exact same signature and return type, so
  api/model.py and the frontend contract never change.
"""

import math
from datetime import datetime
from typing import List

from fastapi import HTTPException

from app.core.constants import SUPPORTED_VARIABLES, DEPTHS
from app.schemas.model import ModelDataResponse

# Mock grid covering the Indian EEZ region roughly (8N-20N, 68E-90E).
LAT_RANGE: List[float] = [round(8 + i * 1.0, 2) for i in range(13)]
LON_RANGE: List[float] = [round(68 + i * 1.0, 2) for i in range(23)]

_BASE_VALUE = {
    "temperature": 28.0,
    "salinity": 35.0,
    "chlorophyll": 0.5,
    "current_u": 0.0,
    "current_v": 0.0,
}


def validate_variable(variable: str) -> None:
    if variable not in SUPPORTED_VARIABLES:
        raise HTTPException(
            status_code=400,
            detail={
                "error": "Unsupported variable",
                "message": f"Variable '{variable}' is not available",
                "available_variables": list(SUPPORTED_VARIABLES.keys()),
            },
        )


def validate_depth(depth: float) -> None:
    if depth < 0:
        raise HTTPException(
            status_code=400,
            detail={
                "error": "Invalid depth",
                "message": "Depth cannot be negative",
            },
        )
    if depth not in DEPTHS:
        raise HTTPException(
            status_code=400,
            detail={
                "error": "Invalid depth",
                "message": f"Depth '{depth}' is not an available depth level",
                "available_depths": DEPTHS,
            },
        )


def validate_time(time: str) -> None:
    try:
        datetime.fromisoformat(time.replace("Z", "+00:00"))
    except ValueError:
        raise HTTPException(
            status_code=400,
            detail={
                "error": "Invalid time",
                "message": f"Time '{time}' is not a valid ISO 8601 timestamp",
                "example": "2026-09-03T12:00:00Z",
            },
        )


def _mock_value(lat: float, lon: float, depth: float, variable: str) -> float:
    """Deterministic pseudo-realistic value: same inputs always give the
    same output, which makes both manual testing and pytest reliable."""
    base = _BASE_VALUE[variable]
    depth_factor = math.exp(-depth / 500.0)
    spatial = math.sin(math.radians(lat * 3)) * math.cos(math.radians(lon * 2))

    if variable == "temperature":
        return round(base * depth_factor + spatial * 1.5, 2)
    if variable == "salinity":
        return round(base + (1 - depth_factor) * 0.8 + spatial * 0.2, 2)
    if variable == "chlorophyll":
        return round(max(0.0, base * depth_factor + spatial * 0.1), 3)
    # current_u / current_v
    return round(spatial * 0.5, 3)


def get_model_data(variable: str, depth: float, time: str) -> ModelDataResponse:
    validate_variable(variable)
    validate_depth(depth)
    validate_time(time)

    values = [
        [_mock_value(lat, lon, depth, variable) for lon in LON_RANGE]
        for lat in LAT_RANGE
    ]

    return ModelDataResponse(
        variable=variable,
        unit=SUPPORTED_VARIABLES[variable]["unit"],
        depth=depth,
        time=time,
        latitude=LAT_RANGE,
        longitude=LON_RANGE,
        values=values,
    )

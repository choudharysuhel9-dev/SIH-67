"""
app/services/current_service.py

Backs GET /api/current.

Reuses model_service's validation and mock value generator for
current_u/current_v so the same grid/values stay consistent with
whatever /api/model would return for those variables.

speed = sqrt(u^2 + v^2)
direction = atan2(v, u), converted to compass-style degrees (0-360,
clockwise from east) for Member 1 to rotate arrow sprites in Cesium.
"""

import math
from typing import List

from app.schemas.current import CurrentPoint, CurrentResponse
from app.services.model_service import (
    validate_depth,
    validate_time,
    _mock_value,
    LAT_RANGE,
    LON_RANGE,
)

# A coarser grid than /api/model - arrows every 3rd grid point avoids
# an unreadably dense arrow field on the frontend.
_CURRENT_LAT_RANGE: List[float] = LAT_RANGE[::3]
_CURRENT_LON_RANGE: List[float] = LON_RANGE[::3]


def get_current(depth: float, time: str) -> CurrentResponse:
    validate_depth(depth)
    validate_time(time)

    points = []
    for lat in _CURRENT_LAT_RANGE:
        for lon in _CURRENT_LON_RANGE:
            u = _mock_value(lat, lon, depth, "current_u")
            v = _mock_value(lat, lon, depth, "current_v")
            speed = round(math.sqrt(u**2 + v**2), 3)
            direction = round(math.degrees(math.atan2(v, u)) % 360, 2)
            points.append(
                CurrentPoint(
                    latitude=lat,
                    longitude=lon,
                    u=u,
                    v=v,
                    speed=speed,
                    direction=direction,
                )
            )

    return CurrentResponse(depth=depth, time=time, points=points)

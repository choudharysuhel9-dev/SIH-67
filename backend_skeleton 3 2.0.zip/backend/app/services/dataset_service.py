"""
app/services/dataset_service.py

Backs GET /api/datasets, /api/variables, /api/times, /api/depths.

STATUS: Mock data only. When real NetCDF is connected, list_times()
and list_depths() should read the actual time/depth coordinates from
the dataset (e.g. ds.time.values, ds.depth.values) instead of the
hardcoded values below — the function signatures and return types
won't need to change.
"""

from datetime import datetime, timedelta, timezone
from typing import List

from app.core.constants import SUPPORTED_VARIABLES, DEPTHS, DATASETS
from app.schemas.dataset import DatasetInfo, VariableInfo


def list_datasets() -> List[DatasetInfo]:
    return [DatasetInfo(**d) for d in DATASETS]


def list_variables() -> List[VariableInfo]:
    return [
        VariableInfo(id=var_id, name=meta["name"], unit=meta["unit"])
        for var_id, meta in SUPPORTED_VARIABLES.items()
    ]


def list_times() -> List[str]:
    """Mock: 10 timestamps, 12 hours apart, starting 2026-09-01T00:00:00Z."""
    base = datetime(2026, 9, 1, 0, 0, 0, tzinfo=timezone.utc)
    return [
        (base + timedelta(hours=12 * i)).strftime("%Y-%m-%dT%H:%M:%SZ")
        for i in range(10)
    ]


def list_depths() -> List[float]:
    return [float(d) for d in DEPTHS]

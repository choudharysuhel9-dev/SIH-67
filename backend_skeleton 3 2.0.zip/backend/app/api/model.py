"""
app/api/model.py

Thin route layer - all logic lives in app/services/model_service.py.
"""

from fastapi import APIRouter, Query

from app.schemas.model import ModelDataResponse
from app.services import model_service

router = APIRouter(tags=["Model"])


@router.get("/model", response_model=ModelDataResponse)
def get_model(
    variable: str = Query(..., description="Variable id, e.g. 'temperature'"),
    depth: float = Query(..., description="Depth in meters, e.g. 50"),
    time: str = Query(..., description="ISO 8601 timestamp, e.g. 2026-09-03T12:00:00Z"),
):
    """Return a gridded model field for a given variable/depth/time."""
    return model_service.get_model_data(variable, depth, time)
